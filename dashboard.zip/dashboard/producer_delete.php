<?php
  include 'connect.php';
  if (isset($_GET['deleteid'])){
    $p_id=$_GET['deleteid'];

    $sql="DELETE FROM `producer` WHERE p_id=$p_id";
    $result=mysqli_query($con,$sql);
    if($result){
        //echo "deleted success...";
        header('location:producer_display.php');
    }
    else{
        die (mysqli_error($con));
    }
  }
?>