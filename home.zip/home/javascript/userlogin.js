 // login.js
document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent form from submitting

    // Get the username and password input values
     username = document.getElementById('loginUsername').value;
     password = document.getElementById('loginPassword').value;

    // Basic validation
    if (username && password) {
        // Show login success message
        alert('Login successful!');
        
        // Redirect to the homepage (replace 'home.html' with the actual home page URL)
        window.location.href = 'dashboard.html';
    } else {
        alert('Please enter both username and password.');
    }
});
