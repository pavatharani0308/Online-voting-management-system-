<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Govid Vasanth | Admin</title>
  <link rel="stylesheet" href="adminprofile.css">

</head>

<body>
  <div class="container">
    <div class="card">

      <h1>Hi, I'm Govid Vasanth!</h1>

      <img src="profile.jpg" alt="profile picture" id="avatar">

      <h2>ADMINISTATOR 💻</h2>

      <p>I'm a former literature student📖, specializing in storytelling and text in video games🎮.<br>Now I'm a ADMINISTATOR 🌐.</p>
    </div>

    <div class="card">
      <h3>Discover some of my works</h3>
      <a class="btn-orange" >Visit my website</a>
      
    </div>
  </div>
</body>
</html>
