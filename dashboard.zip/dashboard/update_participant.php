<?php

include 'connect.php';

$id = $_GET['updateid'];

if (isset($_POST['submit'])) {
    // Retrieving form inputs
    $email = $_POST['email'];
    $ppassword = $_POST['ppassword'];
    
    $sql = "UPDATE `contestant` SET email=?, ppassword=? WHERE p_id=?";

    // Use a prepared statement
    $stmt = $con->prepare($sql);
    $stmt->bind_param("sssi", $email, $ppassword ,$p_id);  // "sssi" indicates 3 strings and 1 integer

    if ($stmt->execute()) {
        echo "Updated successfully...";
        // Optionally, redirect to the display page
        // header('location:display.php');
    } else {
        die("Error updating record: " . $stmt->error);
    }

    // Close the statement
    $stmt->close();
}

// Close the database connection
$con->close();
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IWT Asssignment</title>
    <link rel="stylesheet" href="participant.css">
</head>

<body>
    <section>
        <div class="form-box">
            <div class="form-value">
                <form method="POST" action="participant_display.php">
                    <h2>Login</h2>
                    <div class="input-box">
                        <ion-icon name="mail-outline"></ion-icon>
                        <input type="text" name="p_id" required>
                        <label for="#">Participant ID</label>
                    </div>
                    <div class="input-box">
                        <ion-icon name="mail-outline"></ion-icon>
                        <input type="email" name="email" required>
                        <label for="#">Email</label>
                    </div>
                    <div class="input-box">
                        <ion-icon name="lock-closed-outline"></ion-icon>
                        <input type="password" name="ppassword" required>
                        <label for="#">Password</label>
                    </div>
                    <div class="f-password">
                        <label for="#">
                            <input type="checkbox">
                            Remember Me
                        </label>
                        <a href="#">Forget Password</a>
                    </div>
                    
                    <input type="submit" id="btn" value ="Log In" name="submit">
                    <div class="signup">
                        <p>Don't have an account
                            <a href="#">Register</a>
                        </p>
                    </div>
                </form>
            </div>
        </div>
    </section>
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
</body>

</html>