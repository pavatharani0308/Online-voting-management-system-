<?php
session_start();
include 'connect.php';



if (isset($_POST['vote']))
{
    $contestant = $_POST['contestant'];
    

    foreach($contestant as $item)
    {
       $sql="INSERT INTO `heasvote` (name) VALUES ('$item')";
       $result = mysqli_query($con,$sql);

    }
    if($result)
    {
        $_SESSION['status']="Inserted success";
        header('location:vote_table.php');
    }
    else
    {
        $_SESSION['status']="not success";
        header('location:vote.php');
    }
}


?>
