<?php

session_start();
include 'connect.php';



if (isset($_POST['vote']))
{
    $contestant = $_POST['contestant'];
    

    foreach($contestant as $item)
    {
       $sql="INSERT INTO `heasvote` (name) VALUES ('$item')";
       $result = mysqli_query($con,$sql);

    }
    if($result)
    {
        $_SESSION['status']="Inserted success";
        header('location:vote_table.php');
    }
    else
    {
        $_SESSION['status']="not success";
        header('location:vote.php');
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="vote.css">
    <title>Reality Show Voting Dashboard</title>
</head>
<body>
    
    <div class="vote-dashboard">
    <?php
    if(isset($_SESSION['status']))
    {
        echo "<h2>".$_SESSION['status']."</h2>";
        unset($_SESSION['status']);
    }
   
    ?>

        <img src="img/logo tv.png" alt="Voting System Logo" class="logo">
        <div class="user-profile">
            <img src="img/user.jpg" alt="User Profile Picture" class="profile-pic">
           
        </div>
        <h1>Vote for Your Favorite Contestant</h1>
        <form  action="vote_table.php" method="POST" id="voteForm">
            <div class="contestant">
                <img src="img/boy1.jpg">
                <input type="checkbox" id="contestant1" name="contestant[]" value="Contestant 1">
                <label for="contestant1">Contestant 1</label><br>
            </div>
            <div class="contestant">
                <img src="img/pic1.webp">
                <input type="checkbox" id="contestant2" name="contestant[]" value="Contestant 2">
                <label for="contestant2">Contestant 2</label><br>
            </div>
            <div class="contestant">
                <img src="img/pic_girl.jpg">
                <input type="checkbox" id="contestant3" name="contestant[]" value="Contestant 3">
                <label for="contestant3">Contestant 3</label><br>
            </div>
            <button type="submit" id="voteButton"value="" name="vote" >Submit Vote</button>
        </form>
        <p id="confirmationMessage" class="hidden"></p>

    </div>

    <script src="vote.js"></script>
</body>
</html>
