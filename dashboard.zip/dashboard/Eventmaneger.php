<?php
include 'connect.php';

if (isset($_POST['Login'])) {
    $e_id = $_POST['e_id'];
    $email = $_POST['email'];
    $ppassword = $_POST['ppassword'];
    
    $sql = "INSERT INTO `event` (e_id, email, ppassword) VALUES ( '$e_id', '$email', '$ppassword')";
   $result=mysqli_query($con,$sql);

   if ($result) {
    echo "Inserted successfully...";
   // header('location:display.php');
    
 }
 else{
     die (mysqli_error($con));
 }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login Form</title>
    <link rel="stylesheet" href="Eventmaneger.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
</head>
<body>
    <div class="wrapper">
        <header>Login Form</header>
        <form method="post" action="Eventmaneger_display.php">
            
            <div class="field email">
                <div class="input-area">
                    <input type="text" name="email" placeholder="Email Address">
                    <i class="icon fas fa-envelope"></i>
                    <i class="error error-icon fas fa-exclamation-circle"></i>
                </div>
                <div class="error error-txt">Email can't be blank</div>
            </div>
            <div class="field password">
                <div class="input-area">
                    <input type="password" name="ppassword" placeholder="Password">
                    <i class="icon fas fa-lock"></i>
                    <i class="error error-icon fas fa-exclamation-circle"></i>
                </div>
                <div class="error error-txt">Password can't be blank</div>
            </div>
            <div class="pass-txt"><a href="#">Forgot password?</a></div>
            <input type="submit" name="Login" value="Login">
        </form>
        <div class="sign-txt">Not yet a member? <a href="#">Signup now</a></div>
    </div>
</body>
</html>
