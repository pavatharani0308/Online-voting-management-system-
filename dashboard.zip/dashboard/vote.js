document.addEventListener('DOMContentLoaded', function() {
         voteForm = document.getElementById('voteForm');
         confirmationMessage = document.getElementById('confirmationMessage');

    voteForm.addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent the form from submitting

        // Show the confirmation message in Thanglish
        confirmationMessage.textContent = 'Vote successfully saved!';
        confirmationMessage.classList.remove('hidden'); // Remove the 'hidden' class to show the message

        // Optionally, clear the checkboxes
        const checkboxes = voteForm.querySelectorAll('input[type="checkbox"]');
        checkboxes.forEach(checkbox => {
            checkbox.checked = false;
        });

        // Optionally, hide the confirmation message after a few seconds
        setTimeout(() => {
            confirmationMessage.classList.add('hidden');
        }, 3000); // Hide the message after 3 seconds
    });
});
