<?php

include 'connect.php';

if (isset($_POST['submit'])) {
    $id = $_POST['id'];
    $email = $_POST['email'];
    $ppassword = $_POST['ppassword'];
    $cpassword = $_POST['cpassword'];

    $sql = "INSERT INTO `pava` (id, email, ppassword, cpassword) VALUES ( '$id', '$email', '$ppassword', '$cpassword')";

    $result=mysqli_query($con,$sql);

    if ($result) {
        //echo "Inserted successfully...";
       header('location:display.php');
       
    }
    else{
        die (mysqli_error($con));
    }
}

?>
<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="admin.css">
       
        <title>
            Login
        </title>
        
    </head>
    <body>
        <div id="container">
            <form method="post"  id="form">
                <h1 >ADMINISTRATOR</h1>
                <div id="input-group">
                    <label for="adminname">Admin id</label>
                    <input type="text" id="adminname" name="id" autocomplete="off">
                    <div class="error"></div>
                </div>
                <div id="input-group">
                    <label for="adminname">Email</label>
                    <input type="text" id="email" name="email"autocomplete="off">
                    <div class="error"></div>
                </div>
                <div id="input-group">
                    <label for="password">password</label>
                    <input type="password" id="password" name="ppassword"autocomplete="off">
                    <div class="error"></div>
                </div>
                <div id="input-group">
                    <label for="adminname">Confirm password</label>
                    <input type="password" id="cpassword" name="cpassword"autocomplete="off">
                    <div class="error"></div>
                </div>
                <input type="submit" id="btn"  name="submit">
             </form>
        </div>
    <script src="admin.js"></script>    
    </body>
</html>
