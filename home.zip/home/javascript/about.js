document.getElementById("yourElementId").addEventListener("DOMContentLoaded", function() {
    document.write("About Us page is loaded.");
});

