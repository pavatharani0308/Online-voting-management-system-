<?php

$con =new mysqli('localhost','root','','admin');

// Check connection
if (!$con)
    die (mysqli_error($con));

    
?>

