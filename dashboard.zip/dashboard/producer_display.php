<?php
include 'connect.php';
?>

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="display.css">
<title>
       display
</title>
<body>
<div id="container">
    <button class="btn"><a href="producerlogin.php">Add user</a></button>
    <table class="table">
  <thead>
    <tr>
      
      <th scope="col">Producer id</th>
      <th scope="col">Name</th>
      <th scope="col">Email</th>
      <th scope="col">Password</th>
      <th scope="col">Operations</th>

    </tr>
  </thead>
  <tbody class="divider">
    <?php
        $sql="SELECT * FROM `producer`";
        $result=mysqli_query($con,$sql);
        if($result){
           
            while ($row=mysqli_fetch_assoc($result))
             {
                $p_id=$row['p_id'];
                $name=$row['name'];
                $email=$row['email'];
                $ppassword=$row['ppassword'];
                

                echo '<tr>
                <th scope="$row">'.$p_id.'</th>
                <td>'.$name.'</td>
                <td>'.$email.'</td>
                <td>'.$ppassword.'</td>
                <td>
        <button class="mybtn"><a href="producer_update.php? updateid='.$p_id.'">  Update  </a></button>
    
    </td>
    <td>
    <button class="mybtn1"><a href="producer_delete.php? deleteid='.$p_id.'">  Delete  </a></button>
    </td>
    </tr>';
              }
             }

    ?>
    
   </tbody>
</table>

 </body>
</head>
</html>