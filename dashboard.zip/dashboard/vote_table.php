<?php
include 'connect.php';
?>

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="display.css">
<title>Display</title>
</head>
<body>
<div id="container">
    <button class="btn"><a href="vote.php">Add Voter</a></button>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">Voter ID</th>
                <th scope="col">Name</th>
                <th scope="col">Operations</th>
            </tr>
        </thead>
        <tbody class="divider">
            <?php
                $sql = "SELECT * FROM `heasvote`";
                $result = mysqli_query($con, $sql);
                if ($result) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        $v_id = $row['v_id']; 
                        $contestant = $row['name']; 
                        echo '<tr>
                                <th scope="row">' . $v_id . '</th>
                                <td>' . $contestant . '</td>
                                <td>
                                    <button class="mybtn"><a href="update_vote.php?updateid=' . $v_id . '">Update</a></button>
                                    <button class="mybtn1"><a href="delete_vote.php?deleteid=' . $v_id . '">Delete</a></button>
                                </td>
                              </tr>';
                    }
                }
            ?>
        </tbody>
    </table>
</div>
</body>
</html>
