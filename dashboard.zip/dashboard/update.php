<?php

include 'connect.php';

$id = $_GET['updateid'];
$sql="SELECT * FROM `pava` WHERE id=$id";
$result=mysqli_query($con,$sql);
$row=mysqli_fetch_assoc($result);
$email=$row['email'];
$ppassword=$row['ppassword'];
$cpassword=$row['cpassword'];

if (isset($_POST['submit'])) {
    
    $id = $_POST['id'];
    $email = $_POST['email'];
    $ppassword = $_POST['ppassword'];
    $cpassword = $_POST['cpassword'];

    $sql = "UPDATE `pava` SET email='$email', ppassword='$ppassword', cpassword='$cpassword' WHERE id='$id'";

    $result=mysqli_query($con,$sql);
    if($result)
    {
       // echo "updated";.
       header('location:display.php');
    }

    else{
        die(mysqli_error($con));
    }
}


?>

<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="admin.css">
       
        <title>
            Login
        </title>
        
    </head>
    <body>
        <div id="container">
            <form method="post"  action="display.php"id="form">
                <h1 >ADMINISTRATOR</h1>
                <div id="input-group">
                    <label for="adminname">Admin id</label>
                    <input type="text" id="adminname" name="id" autocomplete="off" value=<?php echo $id; ?>>
                    <div class="error"></div>
                </div>
                <div id="input-group">
                    <label for="adminname">Email</label>
                    <input type="text" id="email" name="email"autocomplete="off" value=<?php echo $email; ?>>
                    <div class="error"></div>
                </div>
                <div id="input-group">
                    <label for="password">password</label>
                    <input type="password" id="password" name="ppassword"autocomplete="off" value=<?php echo $ppassword; ?>>
                    <div class="error"></div>
                </div>
                <div id="input-group">
                    <label for="adminname">Confirm password</label>
                    <input type="password" id="cpassword" name="cpassword"autocomplete="off" value=<?php echo $cpassword; ?>>
                    <div class="error"></div>
                </div>
                <input type="submit" id="btn" value ="update" name="submit">
             </form>
        </div>
    <script src="admin.js"></script>    
    </body>
</html>
