// JavaScript code to handle form submission and display form status
document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("contactForm");
    const formStatus = document.getElementById("form-status");

    form.addEventListener("submit", function (event) {
        event.preventDefault(); // Prevent the default form submission

        // Get form values
        const name = document.getElementById("name").value;
        const email = document.getElementById("email").value;
        const subject = document.getElementById("subject").value;
        const message = document.getElementById("message").value;

        // Simulate form submission success
        setTimeout(() => {
            formStatus.innerHTML = `Thank you, ${name}! Your message has been sent successfully.`;
            formStatus.style.color = "green";
            
            // Reset form fields
            form.reset();
        }, 1000);
    });
});
