<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Responsive Admin & Dashboard</title>
  <link rel="stylesheet" href="admindass.css">
   
  <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
  <div class="sidebar">
    <div class="logo_details">
      <i class='bx bx-code-alt'></i>
      <div class="logo_name">
       </div>
    </div>
    <ul>
      <li>
        <a href="display.php" class="active">
          <i class='bx bx-grid-alt'></i>
          <span class="links_name">
           Admin 
          </span>
        </a>
      </li>
      <li>
      <a href="vote_table.php" class="active">
          <i class='bx bx-grid-alt'></i>
          <span class="links_name">
           vote 
          </span>
        </a>
      </li>
     
      <li>
        <a href="producer_display.php">
          <i class='bx bxs-user-plus'></i>
          <span class="links_name">
            Producer
          </span>
        </a>
      </li>
     
      <li>
        <a href="participant_display.php">
          <i class='bx bxs-user-plus'></i>
          <span class="links_name">
            contestant
         </span>
        </a>
      </li>
      <li>
        <a href="Eventmaneger_display.php">
          <i class='bx bxs-user-plus'></i>
          <span class="links_name">
            Event Manager
          </span>
        </a>
      </li>
      <li>
        <a href="Adminprofile.php">
          <i class='bx bxs-user-plus'></i>
          <span class="links_name">
            Profile
          </span>
        </a>
      </li>
    
      </li>
      <li class="login">
        <a href="admin.php">
          <span class="links_name login_out">
            Login Out
          </span>
          <i class='bx bx-log-out' id="log_out"></i>
        </a>
      </li>
    </ul>
  </div>
 
  <section class="home_section">
    <div class="topbar">
      <div class="toggle">
        <i class='bx bx-menu' id="btn"></i>
      </div>
      
      <div class="user_wrapper">
        <img src="img/user.jpg" alt="admin">
      </div>
    </div>
    
    <div class="card-boxes">
      <div class="box">
        <div class="right_side">
          <div class="numbers">534</div>
          <div class="box_topic">Active Users</div>
        </div>
        <i class='bx bx-cart-alt'></i>
      </div>
      <div class="box">
        <div class="right_side">
          <div class="numbers">150000</div>
          <div class="box_topic">Total Viwers</div>
        </div>
        <i class='bx bxs-cart-add'></i>
      </div>
      <div class="box">
        <div class="right_side">
          <div class="numbers">400,000</div>
          <div class="box_topic">Total votes</div>
        </div>
        <i class='bx bx-cart'></i>
      </div>
      <div class="box">
        <div class="right_side">
          <div class="numbers">5,512</div>
          <div class="box_topic">Rejected Votes</div>
        </div>
        <i class='bx bxs-cart-download'></i>
      </div>
    </div>

    <div class="details">
      <div class="recent_project">
        <div class="card_header">
          <h2>Lastet Projects</h2>
        </div>
        <table>
          <thead>
            <tr>
              <td>Project Name</td>
              <td>Hours</td>
              <td>Priority</td>
              <td>Members</td>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Sa Re Ga Ma Pa</td>
              <td>34</td>
              <td>
                <span class="badge bg_worning">
                  Meduim
                </span>
              </td>
              <td>
                <span class="img_group">
                  <img src="img/avatar-2.jpg" alt="">
                </span>
                <span class="img_group">
                  <img src="img/avatar-3.jpg" alt="">
                </span>
                <span class="img_group">
                  <img src="img/avatar-4.jpg" alt="">
                </span>
                <span class="img_group">
                  <span class="initial">+5</span>
                </span>
              </td>
            </tr>
            <tr>
              <td>Tamila Tamila</td>
              <td>47</td>
              <td>
                <span class="badge bg_danger">
                  Higt
                </span>
              </td>
              <td>
                <span class="img_group">
                  <img src="img/avatar-5.jpg" alt="">
                </span>
                <span class="img_group">
                  <img src="img/avatar-2.jpg" alt="">
                </span>
                <span class="img_group">
                  <img src="img/avatar-3.jpg" alt="">
                </span>
                <span class="img_group">
                  <span class="initial">+5</span>
                </span>
              </td>
            </tr>
            <tr>
              <td>Big boss</td>
              <td>120</td>
              <td>
                <span class="badge bg_info">
                  Low
                </span>
              </td>
              <td>
                <span class="img_group">
                  <img src="img/avatar-4.jpg" alt="">
                </span>
                <span class="img_group">
                  <img src="img/avatar-5.jpg" alt="">
                </span>
                <span class="img_group">
                  <img src="img/avatar-2.jpg" alt="">
                </span>
                <span class="img_group">
                  <span class="initial">+1</span>
                </span>
              </td>
            </tr>
            <tr>
              <td>Cook With Comali</td>
              <td>89</td>
              <td>
                <span class="badge bg_worning">
                  Meduim
                </span>
              </td>
              <td>
                <span class="img_group">
                  <img src="img/avatar-3.jpg" alt="">
                </span>
                <span class="img_group">
                  <img src="img/avatar-4.jpg" alt="">
                </span>
                <span class="img_group">
                  <img src="img/avatar-5.jpg" alt="">
                </span>
                <span class="img_group">
                  <span class="initial">+5</span>
                </span>
              </td>
            </tr>
            <tr>
              <td>Super Singer</td>
              <td>108</td>
              <td>
                <span class="badge bg_seccuss">
                  Track
                </span>
              </td>
              <td>
                <span class="img_group">
                  <img src="img/avatar-2.jpg" alt="">
                </span>
                <span class="img_group">
                  <img src="img/avatar-3.jpg" alt="">
                </span>
                <span class="img_group">
                  <img src="img/avatar-4.jpg" alt="">
                </span>
                <span class="img_group">
                  <span class="initial">+5</span>
                </span>
              </td>
            </tr>
            <tr>
              <td>Sun Singer</td>
              <td>12</td>
              <td>
                <span class="badge bg_info">
                  Low
                </span>
              </td>
              <td>
                <span class="img_group">
                  <img src="img/avatar-5.jpg" alt="">
                </span>
                <span class="img_group">
                  <img src="img/avatar-2.jpg" alt="">
                </span>
                <span class="img_group">
                  <img src="img/avatar-3.jpg" alt="">
                </span>
                <span class="img_group">
                  <span class="initial">+1</span>
                </span>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <div class="recent_customers">
        <div class="card_header">
          <h2>Staff List</h2>
        </div>
        <table>
          <tbody>
            <tr>
              <td>
                <div class="info_img">
                  <img src="img/avatar-2.jpg" alt="">
                </div>
              </td>
              <td>
                <h4>Pavatharani</h4>
                <span>pavatharani@gmail.com</span>
              </td>
            </tr>
            <tr>
              <td>
                <div class="info_img">
                  <img src="img/avatar-3.jpg" alt="">
                </div>
              </td>
              <td>
                <h4>K M C Majo</h4>
                <span>croos@gmail.com</span>
              </td>
            </tr>
            <tr>
              <td>
                <div class="info_img">
                  <img src="img/avatar-4.jpg" alt="">
                </div>
              </td>
              <td>
                <h4>Dirushanth</h4>
                <span>dirushanth@gmail.com</span>
              </td>
            </tr>
            <tr>
              <td>
                <div class="info_img">
                  <img src="img/avatar-5.jpg" alt="">
                </div>
              </td>
              <td>
                <h4>Heasma</h4>
                <span>heasma@gmail.com</span>
              </td>
            </tr>
            <tr>
              <td>
                <div class="info_img">
                  <img src="img/avatar-2.jpg" alt="">
                </div>
              </td>
              <td>
                <h4>Kajaluxan</h4>
                <span>kajaluxan@gmail.com</span>
              </td>
            </tr>
            <tr>
              <td>
                <div class="info_img">
                  <img src="img/avatar-3.jpg" alt="">
                </div>
              </td>
              <td>
                <h4>Hirsan</h4>
                <span>hirsan@gmail.com</span>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </section>

  <script>
    let sidebar = document.querySelector(".sidebar");
    let closeBtn = document.querySelector("#btn");

    closeBtn.addEventListener("click", () => {
      sidebar.classList.toggle("open");
      // call function
      changeBtn();
    });

    function changeBtn() {
      if(sidebar.classList.contains("open")) {
        closeBtn.classList.replace("bx-menu", "bx-menu-alt-right");
      } else {
        closeBtn.classList.replace("bx-menu-alt-right", "bx-menu");
      }
    }
  </script>
</body>
</html>