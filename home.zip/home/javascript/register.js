
        function validateForm(event) {
            event.preventDefault(); // Prevent the form from submitting

            // Get password and confirm password values
            const password = document.getElementById('regPassword').value;
            const confirmPassword = document.getElementById('confirmPassword').value;

            // Check if passwords match
            if (password !== confirmPassword) {
                alert("Passwords do not match! Please try again.");
                return;
            }

            // If passwords match, submit the form and show success message
            // You may want to do additional checks here before submission
            alert("Registration successful!");
            document.getElementById('registrationForm').submit(); // Submit the form
        
};
