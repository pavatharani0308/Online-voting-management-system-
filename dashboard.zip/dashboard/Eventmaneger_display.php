<?php
include 'connect.php';
?>


<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="display.css">
<title>
       display
</title>
<body>
<div id="container">
    <button class="btn"><a href="Eventmaneger.php">Add user</a></button>
    <table class="table">
  <thead>
    <tr>
      
      <th scope="col">Eventmaneger id</th>
      <th scope="col">Email</th>
      <th scope="col">Password</th>
      <th scope="col"> Operations</th>

    </tr>
  </thead>
  <tbody class="divider">
    <?php
        $sql="SELECT * FROM `event`";
        $result=mysqli_query($con,$sql);
        if($result){
           
            while ($row=mysqli_fetch_assoc($result))
             {
             
                $e_id=$row['e_id'];
                $email=$row['email'];
                $ppassword=$row['ppassword'];
                

                echo '<tr>
                <th scope="$row">'.$e_id.'</th>
                <td>'.$email.'</td>
                <td>'.$ppassword.'</td>
                
                <td>
        <button class="mybtn"><a href="Eventmaneger_update.php? updateid='.$e_id.'">  Update  </a></button>
    
    </td>
    <td>
    <button class="mybtn1"><a href="Eventmaneger_delete.php? deleteid='.$e_id.'">  Delete  </a></button>
    </td>
    </tr>';
              }
             }

    ?>
    
   </tbody>
</table>

 </body>
</head>
</html>