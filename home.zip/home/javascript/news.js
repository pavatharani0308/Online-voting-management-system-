// Function to redirect to the respective news page
function readMore(page) {
    window.location.href = page;
}
