


CREATE TABLE `contestant` (
  `p_id` int(8) NOT NULL,
  `email` varchar(60) NOT NULL,
  `ppasword` int(11) NOT NULL
)


CREATE TABLE `event` (
  `e_id` int(11) NOT NULL,
  `email` varchar(60) NOT NULL,
  `ppassword` varchar(8) NOT NULL
) 



CREATE TABLE `heasvote` (
  `name` varchar(25) NOT NULL,
  `v_id` int(11) NOT NULL
) 



CREATE TABLE `pava` (
  `id` int(11) NOT NULL,
  `cpassword` varchar(8) NOT NULL,
  `ppassword` varchar(8) NOT NULL,
  `email` varchar(50) NOT NULL
) 

--
-- Dumping data for table `pava`
--

INSERT INTO `pava` (`id`, `cpassword`, `ppassword`, `email`) VALUES
(1345, '09876543', '09876543', 'abc123@mail.com'),
(30803, '03080309', '03080309', 'pava1234@mail.com');

-- --------------------------------------------------------

--
-- Table structure for table `producer`
--

CREATE TABLE `producer` (
  `p_id` int(11) NOT NULL,
  `email` varchar(60) NOT NULL,
  `name` varchar(40) NOT NULL,
  `ppassword` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contestant`
--
ALTER TABLE `contestant`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`e_id`);

--
-- Indexes for table `heasvote`
--
ALTER TABLE `heasvote`
  ADD PRIMARY KEY (`v_id`);

--
-- Indexes for table `pava`
--
ALTER TABLE `pava`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `producer`
--
ALTER TABLE `producer`
  ADD PRIMARY KEY (`p_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `heasvote`
--
ALTER TABLE `heasvote`
  MODIFY `v_id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
