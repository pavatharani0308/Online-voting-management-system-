<?php

include 'connect.php';

if (isset($_POST['submit'])) {
    $p_id = $_POST['p_id'];
    $email = $_POST['email'];
    $ppassword = $_POST['ppassword'];
   

    $sql = "INSERT INTO `contestant` (p_id, email, ppassword ) VALUES ( '$p_id', '$email', '$ppassword' )";

    $result=mysqli_query($con,$sql);

    if ($result) {
        echo "Inserted successfully...";
       //header('location:display_contestant.php');       
    }
    else{
        die (mysqli_error($con));
    }
}
?>
<?php
include 'connect.php';
?>


<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="display.css">
<title>
       display
</title>
<body>
<div id="container">
    <button class="btn"><a href="participant.php">Add contestant</a></button>
    <table class="table">
  <thead>
    <tr>
      
      <th scope="col">Participant id</th>
      <th scope="col">Email</th>
      <th scope="col">Password</th>
      <th scope="col">Operations</th>
     

    </tr>
  </thead>
  <tbody class="divider">
    <?php
        $sql="SELECT * FROM `contestant`";
        $result=mysqli_query($con,$sql);
        if($result){
           
            while ($row=mysqli_fetch_assoc($result))
             {
             
                $p_id=$row['p_id'];
                $email=$row['email'];
                $ppassword=$row['ppassword'];
               

                echo '<tr>
                <th scope="$row">'.$p_id.'</th>
                <td>'.$email.'</td>
                <td>'.$ppassword.'</td>
                
                <td>
        <button class="mybtn"><a href="update_participant.php? updateid='.$p_id.'">  Update  </a></button>
    
    </td>
    <td>
    <button class="mybtn1"><a href="delete_participant.php? deleteid='.$p_id.'">  Delete  </a></button>
    </td>
    </tr>';
              }
             }

    ?>
    
   </tbody>
</table>

 </body>
</head>
</html>