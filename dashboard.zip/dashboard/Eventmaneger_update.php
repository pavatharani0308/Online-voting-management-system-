<?php

include 'connect.php';

$e_id = $_GET['updateid'];

if (isset($_POST['Login'])) {
    
    $email = $_POST['email'];
    $ppassword = $_POST['ppassword'];

  
    // Prepare the SQL statement using prepared statements to prevent SQL injection
    $sql = "UPDATE `event` SET email=?, ppassword=? WHERE e_id=?";

    // Use a prepared statement
    $stmt = $con->prepare($sql);
  // "sssi" indicates 3 strings and 1 integer

    // Execute the query and check the result
    if ($stmt->execute()) {
        echo "Updated successfully...";
        // Optionally, redirect to the display page
        // header('location:display.php');
    } else {
        die("Error updating record: " . $stmt->error);
    }

    // Close the statement
    $stmt->close();
}

// Close the database connection
$con->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login Form</title>
    <link rel="stylesheet" href="Eventmaneger.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
</head>
<body>
    <div class="wrapper">
        <header>Login Form</header>
        <form method="post" >
            
            <div class="field email">
                <div class="input-area">
                    <input type="text" name="email" placeholder="Email Address">
                    <i class="icon fas fa-envelope"></i>
                    <i class="error error-icon fas fa-exclamation-circle"></i>
                </div>
                <div class="error error-txt">Email can't be blank</div>
            </div>
            <div class="field password">
                <div class="input-area">
                    <input type="password" name="ppassword" placeholder="Password">
                    <i class="icon fas fa-lock"></i>
                    <i class="error error-icon fas fa-exclamation-circle"></i>
                </div>
                <div class="error error-txt">Password can't be blank</div>
            </div>
            <div class="pass-txt"><a href="#">Forgot password?</a></div>
            <input type="submit" name="Login" value="update">
        </form>
        <div class="sign-txt">Not yet a member? <a href="#">Signup now</a></div>
    </div>
</body>
</html>